This folder contains spike train data that were used to 
compare the synchrony measure "Spike-contrast" with "SPIKE-distance"




1-poisson_spikes, 2-poisson_bursts, 4-sub-bursts:

Folder structure: 		.../*N*-N/*F*.mat (N = 1...20 independent simulations, F = 1...21 synchrony levels) 
Data format: 			.mat (MATLAB)
Data structure:
S.M_TS:				matrix containing spike time stamps in seconds (column 1: spike train 1, column 2: spike train 2)
S.rec_dur:			signal length in seconds
S.percentage:			equates factor "F" in manuscript (0: high synchrony, 1: low synchrony) 




3-Izhikevich_network:

Folder structure: 		.../Sim*N*/*F*_TS.mat (N = 1...20 independent simulations, F = 1...20 synchrony levels) 
Data format: 			.mat (MATLAB)
Data structure:
SPIKEZ.TS:			matrix containing spike time stamps in seconds (column 1: spike train 1, column 2: spike train 2, ect.)
SPIKEZ.PREF.rec_dur:		signal length in seconds
SPIKEZ.PREF.SynStrength:	equates factor "F" in manuscript (0: high synchrony, 1: low synchrony) 

